﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_Project4
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load1(object sender, EventArgs e)
        {

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void WithdrawalButton_Click(object sender, EventArgs e)
        {
            
            ATM.withdrawal = Convert.ToDouble(WithdrawalTextBox.Text);

            if (ATM.withdrawal < 0)
            {
                WithdrawalLabel.Text = "Please enter valid amount!";
            }
            else if (ATM.withdrawal > ATM.balance)
            {
                WithdrawalLabel.Text = "insufficient funds!";
            }
            else
            {
                ATM.balance -= ATM.withdrawal;
                WithdrawalLabel.Text = "you have take out: $" + ATM.withdrawal + " from your account. Go to balance to see your new amount";
            }
        }
    }
}