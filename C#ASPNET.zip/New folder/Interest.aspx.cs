﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace ASPNET_Project4
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load3(object sender, EventArgs e)
        {

        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void InterestButton_Click(object sender, EventArgs e)
        {
            
            ATM.interest = ATM.balance * ATM.interest;
            InterestLabel.Text = "Your Interest of 1% based on your balance is: $" + ATM.interest.ToString();
        }
    }
}