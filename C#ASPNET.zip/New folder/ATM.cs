﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPNET_Project4
{
    static public class ATM
    {
        //accounts
        //protected values

        static double Balance, Withdrawal, Deposit, Interest;

        //public values

        static public double balance
        {
            get { return Balance; }
            set { Balance = value; }
        }

        static public double withdrawal
        {
            get { return Withdrawal; }
            set { Withdrawal = value; }
        }

        static public double deposit
        {
            get { return Deposit; }
            set { Deposit = value; }
        }

        static public double interest
        {
            get { return Interest; }
            set { Interest = value; }
        }

        //constructor
        static ATM()
        {
            Balance = 550;
            Interest = 0.01;
            Withdrawal = 0;
            Deposit = 0;
        }
    }
}