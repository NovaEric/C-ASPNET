﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        int heads = 0;
        int tails = 0;

        public Form1()
        {
            InitializeComponent();
            
        }

        //toss the coin randomly 
        private int randomToss()
        {
            int Ranber;

            Random rnd = new Random();
            if (rnd.Next(2) == 1)
            {

                Ranber = 2;

            }
            else
            {

                Ranber = 1;

            }

            return Ranber;
        }

        private void button1_Click(object sender, EventArgs e)
        {
                                

            //toss coin
            for (int i = 0; i <= 10; i++)
            {

                randomToss();

            }

            //find results
            if (randomToss() == 1)
            {
                
                pictureBox1.Image = Properties.Resources.Heads2;
                pictureBox1.Visible = true;
                pictureBox2.Visible = false;
                label3.Text = Convert.ToString(heads);
                heads++;
                label5.Text = "Heads Won!";
                label5.Visible = true;
            }
            else
            {
                pictureBox2.Image = Properties.Resources.Tails2;
                pictureBox1.Visible = false;
                pictureBox2.Visible = true;
                label4.Text = Convert.ToString(tails);
                tails++;
                label5.Text = "Tails Won!";
                label5.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
