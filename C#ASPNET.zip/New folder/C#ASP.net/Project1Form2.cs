﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1
{
    public partial class Form2 : Form
    {

        int hoursworked = 0;
        public Form2()
        {
            InitializeComponent();
            
        }

        public void button1_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {

                MessageBox.Show("Please, Fill out all fields!");
            }
            else
            {
                hoursworked = Convert.ToInt32(textBox3.Text);
                NovaINC novaINC = new NovaINC(this);
                novaINC.Show();
                this.Hide();
                
            }

        }

        public void clearner()
        {
            button1.Visible = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        public void display(int pay, string D)
        {
            button1.Text = D + ": " + Convert.ToInt32(pay);
            button1.Visible = true;
            linkLabel1.Visible = true;
                       
        }

        public string fname
        {
             
           get { return textBox1.Text; }
            
        }

        public string lname
        {
            get { return textBox2.Text; }
            
        }

        public int hour
        {
           
            get { return hoursworked; }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            linkLabel1.Hide();
           
        }

        public void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Visible = false;
            button1.Visible = false;
            linkLabel1.Hide();
            NovaINC novaINC = new NovaINC(this);
            novaINC.Show();
        }
    }
}
