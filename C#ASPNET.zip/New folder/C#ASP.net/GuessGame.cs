﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace GuessGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
                        
        }

        //global variable for timer
        int duration;
        //variables
        int randomNumber;
        int playerChoice;
        int attempt;
        //button as msgbox
        private void button1_Click(object sender, EventArgs e)
        {
            duration = 10;
            timer1.Enabled = true;
            timer1.Start();

            label3.Visible = false;
            label1.Visible = true;
            button1.Visible = false;
            listBox1.Visible = true;
            button2.Visible = true;
            label2.Visible = true;

        }
        //Timer
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            duration--;

            if (duration == 0)
            {
                label1.Visible = false;
                timer1.Stop();
                timer1.Enabled = false;
                label3.Visible = true;
                listBox1.Visible = false;
                button2.Visible = false;
                label2.Visible = false;
                duration = 10;
                button1.Visible = true;
                label3.Text = "You Ran out of Time try again later";
                button1.Dispose();
            }
            else
            {
                label1.Text = Convert.ToString(duration);
            }
           

        }
        //play Button
        private void button2_Click(object sender, EventArgs e)
        {
            
            label1.Visible = false;
            timer1.Stop();
            timer1.Enabled = false;
            label3.Visible = true;
            listBox1.Visible = false;
            button2.Visible = false;
            label2.Visible = false;

            // counter
            attempt = attempt + 1;

            bool gameOver = false;

            
            //run loop until the game is over

            if(!gameOver)
            {                             

                //generate a random number for the computer using a function
                randomNumber = GenerateRandom();

                //check for invalid entry
                

                try
                {
                    playerChoice = Convert.ToInt32(listBox1.Text);
                
                    //run function to find the result
                    gameOver = FindResult(randomNumber, playerChoice, attempt);
                }
                catch (Exception)
                {

                    label1.Visible = false;
                    timer1.Stop();
                    timer1.Enabled = false;
                    label3.Visible = true;
                    listBox1.Visible = false;
                    button2.Visible = false;
                    label2.Visible = false;
                    button1.Visible = true;
                    button1.Text = "Invalid Entry";
                    
                }
                
            }           

        }
        //Random number
        int GenerateRandom()
        {
            Random rnd = new Random();
            return rnd.Next(21);
        }

        //get result

        bool FindResult(int randomNumber, int playerChoice, int attempt)
        {

            if (attempt <= 10)
            {
                if (playerChoice == randomNumber)
                {
                    button1.Visible = true;
                    button1.Text = "You Guessed Number " + playerChoice + " --- Well Done!";
                    attempt = 0;
                    return true;
                }
                else
                {
                    button1.Visible = true;
                    button1.Text = "Sorry Try again " + "the Number was " + randomNumber;
                    
                    return false;
                }
            }
            else
            {
                button1.Visible = true;
                label3.Text = "You Ran out of attempts try again later";
                button1.Dispose();            
                return true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
