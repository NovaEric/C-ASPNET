﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsharpLab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            UserNumbers();
           
        }

        private void UserNumbers()
        {
            button1.Visible = false;
            button2.Visible = true;
            button3.Visible = true;
            int[] usernumber = new int[5];
            int[] lotterynumbers = new int[5];

            int min = 0;
            int max = 9;
            int counter = 0;
            Random Lottery = new Random();
            Lottery.Next(min, max);

            try
            {

                usernumber[0] = Convert.ToInt32(textBox1.Text);
                usernumber[1] = Convert.ToInt32(textBox2.Text);
                usernumber[2] = Convert.ToInt32(textBox3.Text);
                usernumber[3] = Convert.ToInt32(textBox4.Text);
                usernumber[4] = Convert.ToInt32(textBox5.Text);


                for (int i = 0; i <= usernumber.Length - 1; i++)
                {
                    if (usernumber[i] > 9 || usernumber[i] < 0)
                    {

                        MessageBox.Show("Enter numbers from 0 to 9!");
                        break;

                    }                   
                    else
                    {

                        lotterynumbers[i] = Lottery.Next(min, max);
                        label1.Text += lotterynumbers[i].ToString() + " ";
                        label2.Text += usernumber[i].ToString() + " ";
                    }

                    if (usernumber[i] == lotterynumbers[i])
                    {
                        counter++;

                    }

                    if (counter == 5)
                    {
                        button3.Text = "You Win";
                    }
                    else
                    {
                        button3.Text = "you matched " + counter + " of the Jackpoint" ;
                    }
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Enter some numbers!");
                
            }

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = false;
            button3.Visible = false;
            label1.Text = "";
            label2.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";

        }
    }
}
