﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class NovaCalc : Form
    {
        public NovaCalc()
        {
            InitializeComponent();
        }

        private void add_Click(object sender, EventArgs e)
        {
            double fnumber, snumber, answer;

            fnumber = Convert.ToDouble(fnumbertext.Text);
            snumber = Convert.ToDouble(snumbertext.Text);

            answer = fnumber + snumber;

            result.Text = Convert.ToString(answer); 
        }

        private void clearb_Click(object sender, EventArgs e)
        {
            result.Text = "";
            fnumbertext.Text = "";
            snumbertext.Text = "";
        }

        private void subtract_Click(object sender, EventArgs e)
        {
            double fnumber, snumber, answer;

            fnumber = Convert.ToDouble(fnumbertext.Text);
            snumber = Convert.ToDouble(snumbertext.Text);

            answer = fnumber - snumber;

            result.Text = Convert.ToString(answer);
        }

        private void Div_Click(object sender, EventArgs e)
        {
            double fnumber, snumber, answer;

            fnumber = Convert.ToDouble(fnumbertext.Text);
            snumber = Convert.ToDouble(snumbertext.Text);

            answer = fnumber / snumber;

            result.Text = Convert.ToString(answer);
        }

        private void Multi_Click(object sender, EventArgs e)
        {
            double fnumber, snumber, answer;

            fnumber = Convert.ToDouble(fnumbertext.Text);
            snumber = Convert.ToDouble(snumbertext.Text);

            answer = fnumber * snumber;

            result.Text = Convert.ToString(answer);
        }

        private void exitb_Click(object sender, EventArgs e)
        {
            Close();        }
    }
}
