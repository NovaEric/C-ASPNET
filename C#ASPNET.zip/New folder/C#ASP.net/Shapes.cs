﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2ShapesCsharp
{
    public partial class Shapes : Form
    {
        public Shapes()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            int val = 10;

            int i, j, k;


            for (i = 0; i <= val; i++)
            {
                for (j = 0; j <= i; j++)
                {

                    label1.Text += "";

                }
                for (k = 0; k <= i; k++)
                {
                    
                    label1.Text += "*";
                    
                }
                for (j = 10; j >= i; j--)
                {

                    label1.Text += "";

                }
                for (k = 10; k >= i; k--)
                {

                    label1.Text += "";

                }
                label1.Text += " ";
                label1.Text += Environment.NewLine;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = false;
            button4.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            label1.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            button7.Visible = false;

            int val = 10;

            int i, j, k;


            for (i = 0; i <= val; i++)
            {

                for (j = 10; j >= i; j--)
                {

                    label1.Text += "";

                }
                for (k = 10; k >= i; k--)
                {

                    label1.Text += " ";

                }
                for (j = 0; j <= i; j++)
                {

                    label1.Text += " *";
                   
                }
                for (k = 0; k <= i; k++)
                {

                    label1.Text += "";

                }
               
                label1.Text += "";
                label1.Text += Environment.NewLine;
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            int val = 10;

            int i, j, k;


            for (i = 0; i <= val; i++)
            {
                for (j = 0; j <= i; j++)
                {

                    label1.Text += "";

                }
                for (k = 0; k <= i; k++)
                {

                    label1.Text += " ";

                }
                for (j = 10; j >= i; j--)
                {

                    label1.Text += " *";

                }
                for (k = 10; k >= i; k--)
                {

                    label1.Text += "";

                }
                label1.Text += " ";
                label1.Text += Environment.NewLine;
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            button7.Visible = false;

            int val = 9;

            int i, j;

            for ( i = - val; i <= val; i++)
            {
                for ( j = - val; j <= val ; j++)
                {
                    label1.Text += " ";

                    if (i*i <= j*j)
                    {
                        label1.Text += " *";
                    }
                    else
                    {
                        label1.Text += "  ";
                    }

                    label1.Text += " ";

                }              
               
                label1.Text += Environment.NewLine;
            }
        }

        private void Shapes_Load(object sender, EventArgs e)
        {

        }
    }
}
