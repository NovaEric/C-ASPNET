﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            Result();
            Label5.Text = scoreCPU.ToString();
            Label6.Text = scoreUser.ToString();

        }
        //scoreCPU
        static int scoreCPU;

        //scoreUser
        static int scoreUser;
       
        //get CPU choice
        private int CPU()
        {
            Random cpu = new Random();
            return cpu.Next(3);
        }
        //get result
        private void Result()
        {
            int user, cpu;

            cpu = CPU();
                        
            try
            {
                user = Convert.ToInt32(TextBox1.Text);
                if (user >= 1 || user <= 3)
                {

                    //User
                    if (user == 1)
                    {
                        Label1.Text = "picked rock";
                    }
                    else if (user == 2)
                    {
                        Label1.Text = "picked Paper";
                    }
                    else
                    {
                        Label1.Text = "picked Sccisor";
                    }

                    //CPU
                    if (cpu == 1)
                    {
                        Label3.Text = "picked rock";
                    }
                    else if (cpu == 2)
                    {
                        Label3.Text = "picked Paper";
                    }
                    else
                    {
                        Label3.Text = "picked Sccisor";
                    }

                    //result
                    if (user == cpu)
                    {
                         Label4.Text = "Tie, play again";
                    }
                    else if ((user == 1 && cpu == 3) || (user == 2 && cpu == 1) || (user == 3 && cpu == 2))
                    {
                        Label4.Text = "You win!";
                        scoreUser += 1;
                    }
                    else
                    {
                        Label4.Text = "You lose";
                        scoreCPU += 1;
                    }

                }
                else
                {
                    Label1.Text = "Wrong Input!";
                }

                
            }
            catch (Exception)
            {
                Label1.Text = "Wrong Input!";                
            }
            
        }
    }
}