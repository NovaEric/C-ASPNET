﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Project1
{
    public partial class NovaINC : Form
    {
        public NovaINC()
        {
            InitializeComponent();
         
        }
        //connecting Forms
        public Form2 MainForm = null;

        public NovaINC(Form callForm)
        {
            MainForm  = callForm as Form2;
            InitializeComponent();

        }

        //calculate pay
        private int payment(int pay, int hour)
        {
            int payrate;

            payrate = pay * hour;

            return payrate;
        }
        //Weekly
        private int Weekly(int pay)
        {
            int Week, hour;

            hour = 40;

            Week = pay * hour;

            return Week;
        }
        //Byweekly
        private int Biweekly(int pay)
        {
            int Biweek, hour;

            hour = 80;

            Biweek = pay * hour;

            return Biweek;
        }
        //Monthly
        private int Monthly(int pay)
        {
            int Month, hour;

            hour = 160;

            Month = pay * hour;

            return Month;
        }


        private void NovaINC_Load(object sender, EventArgs e)
        {
            fninput.Text = this.MainForm.fname;
            lninput.Text = this.MainForm.lname;
            hoursworked.Text = Convert.ToString(this.MainForm.hour);
        }

        
        private void buttonexit_Click(object sender, EventArgs e)
        {

            this.MainForm.Close();
        
        }

        private void buttonstart_Click(object sender, EventArgs e)
        {           
            this.MainForm.Show();
            this.Hide();
            this.MainForm.clearner();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void buttonpay_Click(object sender, EventArgs e)
        {
            int payhour, hours;
            string strpayrate;

            strpayrate = comboBox1.Text;



            if (strpayrate == "")
            {
                MessageBox.Show("Please, select a payrate value!");

            }
            else
            {
                payhour = Convert.ToInt32(comboBox1.Text);
                hours = this.MainForm.hour;

                buttonshowpay.Text = Convert.ToString(payment(payhour, hours));

                buttonshowpay.Visible = true;
            }
        }

        private void buttonweek_Click(object sender, EventArgs e)
        {
            int payrate = 0;
            string week, strpayrate;
            
            week = "Your Weekly Payment is";

            strpayrate = comboBox1.Text;

                         

            if (strpayrate == "")
            {
                MessageBox.Show("Please, select a payrate value!");

            }
            else
            {
                payrate = Convert.ToInt32(comboBox1.Text);
                this.MainForm.display(Weekly(payrate), week);

                this.MainForm.Show();
                this.Hide();
            }
                       
           
        }

        private void buttonBi_Click(object sender, EventArgs e)
        {
            int payrate;
            string Biweek, strpayrate; ;
        
            Biweek = "Your BiWeekly Payment is";

            strpayrate = comboBox1.Text;



            if (strpayrate == "")
            {
                MessageBox.Show("Please, select a payrate value!");

            }
            else
            {
                payrate = Convert.ToInt32(comboBox1.Text);

                this.MainForm.display(Biweekly(payrate), Biweek);

                this.MainForm.Show();
                this.Hide();
            }
        }

        private void buttonMonth_Click(object sender, EventArgs e)
        {
            int payrate;
            string Month, strpayrate; ;

            Month = "Your Monthly Payment is";

            strpayrate = comboBox1.Text;



            if (strpayrate == "")
            {
                MessageBox.Show("Please, select a payrate value!");

            }
            else
            {
                payrate = Convert.ToInt32(comboBox1.Text);

                this.MainForm.display(Monthly(payrate), Month);

                this.MainForm.Show();
                this.Hide();
            }
        }
    }
}
