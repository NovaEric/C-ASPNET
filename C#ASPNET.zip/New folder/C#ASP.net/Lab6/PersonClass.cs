﻿using System;

public class PersonClass
{
	public PersonClass()
	{
        //Constructor   
        Name = "";
        Address = "";
        PhoneNumber = "";

	}

    //protected fields
    private string Name, Address, PhoneNumber;

    //field to be use for developers

    //get name
    public string name
    {
        get { return Name; }
        set { Name = value; }
    }

    //get address
    public string address
    {
        get { return Address; }
        set { Address = value; }
    }

    //get phone number
    public string phonenumber
    {
        get { return PhoneNumber; }
        set { PhoneNumber = value; }
    }

}
