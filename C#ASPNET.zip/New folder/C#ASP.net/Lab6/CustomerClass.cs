﻿using System;
using PersonClass;

public class CustomerClass : PersonClass
{
	public CustomerClass()
	{
        //Constructor
        CusNumber = 0;
        Mail = true;
	}

    //protected fields
    private int CusNumber;
    private bool Mail;

    //field to be use for developers

    //get Csutomer Number
    public int customernumber
    {
        get { return CusNumber; }
        set { CusNumber = value; }
    }

    //get mail list yes or no
    public bool mailist
    {
        get { return Mail; }
        set { Mail = value; }
    }

}
