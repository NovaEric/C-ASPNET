﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_LAB6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string mail;
            CustomerClass MyCustomer = new CustomerClass();

            MyCustomer.name = TextBox1.Text;
            MyCustomer.address = TextBox2.Text;
            MyCustomer.phonenumber = TextBox3.Text;
            MyCustomer.customernumber = Convert.ToInt32(TextBox4.Text);
            MyCustomer.mailist = DropDownList1.Text;
           

            Label6.Text = "Customer Name is " + MyCustomer.name;
            Label7.Text = "Customer Address is " + MyCustomer.address;
            Label8.Text = "Customer Phone Number is " + MyCustomer.phonenumber;
            Label9.Text = "Customer Number is " + MyCustomer.customernumber;
            Label10.Text = "Customer will get mail? " + MyCustomer.mailist;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            DropDownList1.Text = "";
            Label6.Text = "";
            Label7.Text = "";
            Label8.Text = "";
            Label9.Text = "";
            Label10.Text = "";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            environment.exit(-1);
        }
    }
}