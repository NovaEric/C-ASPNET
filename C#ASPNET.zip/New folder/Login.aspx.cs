﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ASPNET_Project4
{
    public partial class Login : System.Web.UI.Page
    {
        SqlCommand sqlCMD = new SqlCommand();
        SqlConnection sqlCONN = new SqlConnection();
        SqlDataAdapter sqlDA = new SqlDataAdapter();
        DataSet DS = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {

            sqlCONN.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=UserAuth;Integrated Security=True";
            sqlCONN.Open();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            sqlCMD.CommandText = "select * from UserInfo where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
            sqlCMD.Connection = sqlCONN;
            sqlDA.SelectCommand = sqlCMD;
            sqlDA.Fill(DS, "UserInfo");

            if (DS.Tables[0].Rows.Count > 0)
            {
                Response.Redirect("Home.aspx");
            }
            else
            {
                Label1.Text = "Invalid Username or Password!";
            }
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

            
        }
    }
}