﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_Project4
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load4(object sender, EventArgs e)
        {

        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void DepositButton_Click(object sender, EventArgs e)
        {
            

            ATM.deposit = Convert.ToDouble(DepositTextBox.Text);

            if (ATM.deposit < 0)
            {
                DepositLabel.Text = "Please enter valid amount!";
            }
            else
            {
                ATM.balance += ATM.deposit;
                DepositLabel.Text = "you have deposited: $" + ATM.deposit + " to your account. Go to balance to see your new amount"; 
            }
        }
    }
}